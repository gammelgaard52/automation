.\module\getData.ps1 `
    -WsUri "ws://<ip>/ws" `
    -OutputFile "<path>\inverter_data_log.jsonl"