.\module\getData.ps1 `
    -WsUri "ws://192.168.1.78/ws" `
    -OutputFile "C:\VSC\automation\Logger\inverter_data_log.jsonl"