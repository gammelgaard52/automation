# Extract inverter data from local Logger (e.g. AEG/Goodwee)

This PowerShell script suite collects and summarizes solar inverter data from a local WebSocket logger, and stores it in JSONL format. This companion tool helps extract and analyze that data in a readable format.

## Folder Structure

```
Logger/
├── Modules/
│   └── GetData.ps1         # Core reusable functions
├── inverter_data_log.jsonl # Your collected log file
└── run.ps1                 # Main entry script
```

## Example usage

### Show latest reading from log:
```powershell
.
run.ps1 -Mode now
```

### Show average over the last hour:
```powershell
.
run.ps1 -Mode hour
```

### Show daily summaries (average per day):
```powershell
.
run.ps1 -Mode daily-summary
```

Make sure the file `inverter_data_log.jsonl` is located in the same folder as `rrun.ps1`.

## Notes

- Data must be collected using a separate WebSocket logger (not included here).
- The script expects data entries in JSONL format, each line like:

```json
{"messageType":"deviceData","deviceType":"Inverter","activePowerPOC":363,"activePowerInverter":1063,"activePowerSolar":1132,"activePowerBattery":-19,"activePowerGenerator":0,"activePowerUsage":700,"batterySOC":96,"timestamp":"2025-06-27 20:09:50"}
```

## Credits

Created for analyzing inverter telemetry from Goodwee / AEG loggers connected via RS485 to a WebSocket gateway (e.g. custom ESP or vendor logger).
