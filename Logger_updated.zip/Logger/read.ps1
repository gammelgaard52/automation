.\module\readData.ps1 `
    -Mode DailySummary

.\module\readData.ps1 `
    -Mode Hour

.\module\readData.ps1 `
    -Mode Now