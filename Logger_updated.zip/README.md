# Inverter Telemetry Logger & Reader (Goodwee / AEG Compatible)

This PowerShell-based toolset lets you collect and analyze real-time inverter data from WebSocket-enabled inverters such as **Goodwee** or **AEG**.

## 🧩 Modules

- `Modules/Start-Logger.ps1`  
  Connects to a WebSocket endpoint and logs device data to a `.jsonl` file.

- `Modules/Get-InverterData.ps1`  
  Reads and analyzes the `.jsonl` file with output options like latest, hourly average, and daily summaries.

## 🚀 Example Usage

### Log data from your inverter (WebSocket required)

```powershell
.\Modules\Start-Logger.ps1 `
  -WsUri "ws://192.168.1.78/ws" `
  -OutputFile "inverter_data_log.jsonl"
```

> ℹ️ Replace the WebSocket IP and file path with your local configuration.

### Read data from JSON log

```powershell
.\Modules\Get-InverterData.ps1 -Mode Now
.\Modules\Get-InverterData.ps1 -Mode Hour
.\Modules\Get-InverterData.ps1 -Mode DailySummary
```

## 🧪 Output Modes

| Mode           | Description                            |
|----------------|----------------------------------------|
| `Now`          | Show the latest real-time data entry   |
| `Hour`         | Calculate average from the past hour   |
| `DailySummary` | Show daily averages grouped by date    |

## 📝 Notes

- Data is saved in JSON Lines format (`.jsonl`)
- Only `deviceData` messages are recorded
- You can schedule `Start-Logger.ps1` with Task Scheduler for continuous collection

## 🙏 Credits

Original inspiration from:
https://terravolt.co.uk/api-integrations/goodwe-api-integrations/

---

© 2025. You are free to modify and use.
